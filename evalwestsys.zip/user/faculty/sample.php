<?php
echo $_GET['id']."<br>".$_GET['acad_yr']."<br>".$_GET['acad_sem'];
?>